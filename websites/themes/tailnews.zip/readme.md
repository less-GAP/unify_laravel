# First of all, we thank you for your purchase and willingness of using Tailnews in your projects! #

Tailnews is Tailwind News Template, this template is easy to development.

### How to start with Tailnews? ###

It's simple and easy, just open `docs/index.html` and Tailnews documentation will guide you with detailed step by step information.

### License ###

Tailnews is licensed under Tailnet License and you can find more detailed information about it in https://tailwindtemplate.net/license/

### Free updates and support ###

After purchasing a Tailnews Template copy, you get the right for a lifetime entitlement to download updates for FREE! Need help? For any questions or concerns, reach us out at support@tailwindtemplate.net

### Have idea for next update? ###

If you have any idea for next update or find bugs in template, We is very happy if you give idea or suggestion to support@tailwindtemplate.net